/*
*
* 建议的css样式表
*
* .typed-cursor{
 opacity: 1;
 font-weight: 100;
 -webkit-animation: blink 0.7s infinite;
 -moz-animation: blink 0.7s infinite;
 -ms-animation: blink 0.7s infinite;
 -o-animation: blink 0.7s infinite;
 animation: blink 0.7s infinite;
 }
 @keyframes blink{
 0% { opacity:1; }
 50% { opacity:0; }
 100% { opacity:1; }
 }
 @-webkit-keyframes blink{
 0% { opacity:1; }
 50% { opacity:0; }
 100% { opacity:1; }
 }
 @-moz-keyframes blink{
 0% { opacity:1; }
 50% { opacity:0; }
 100% { opacity:1; }
 }
 @-ms-keyframes blink{
 0% { opacity:1; }
 50% { opacity:0; }
 100% { opacity:1; }
 }
 @-o-keyframes blink{
 0% { opacity:1; }
 50% { opacity:0; }
 100% { opacity:1; }
 }

 .typed-fade-out{
 opacity: 0;
 animation: 0;
 transition: opacity .25s;
 }
*
*
* */

! function(window, document, $) {

	var Typed = function(el, options) {
		var self = this;
		this.el = el;

		this.options = {};
		/*  将默认的属性和值，附加到options对象上 */
		Object.keys(defaults).forEach(function(key) {
			self.options[key] = defaults[key];
		});
		/* 如果传入了对象，对象中存在响应的值，将相应的值附加给对象 */
		Object.keys(options).forEach(function(key) {
			self.options[key] = options[key];
		});

		this.isInput = this.el.tagName.toLowerCase() === 'input';
		this.attr = this.options.attr;

		this.showCursor = this.isInput ? false : this.options.showCursor;

		this.elContent = this.attr ? this.el.getAttribute(this.attr) : this.el.textContent;

		this.contentType = this.options.contentType;

		this.typeSpeed = this.options.typeSpeed;

		this.startDelay = this.options.startDelay;

		this.backSpeed = this.options.backSpeed;

		this.backDelay = this.options.backDelay;

		this.fadeOut = this.options.fadeOut;
		this.fadeOutClass = this.options.fadeOutClass;
		this.fadeOutDelay = this.options.fadeOutDelay;

		if($ && this.options.stringsElement instanceof $) {
			this.stringsElement = this.options.stringsElement[0]
		} else {
			this.stringsElement = this.options.stringsElement;
		}

		this.strings = this.options.strings;

		this.strPos = 0;

		this.arrayPos = 0;

		this.stopNum = 0;

		this.loop = this.options.loop;
		this.loopCount = this.options.loopCount;
		this.curLoop = 0;

		this.stop = false;

		this.cursorChar = this.options.cursorChar;

		this.shuffle = this.options.shuffle;
		/* 存放即将打印的字符串 */
		this.sequence = [];
		/* 程序在此处开始运行 */
		this.build();
	};

	Typed.prototype = {
		constructor: Typed,
		init: function() {
			var self = this;
			self.timeout = setTimeout(function() {
				/* strings为设置的待打印的字符串数组 */
				/* sequence[i]主要来控制strings[]中字符串的打印顺序 */
				for (var i=0;i<self.strings.length;++i)
					self.sequence[i]=i;

				// 设置随机显示字符串
				if(self.shuffle)
					/* 调用shuffleArray()函数来随机排序数组 */
					self.sequence = self.shuffleArray(self.sequence);

				// 打印字符串
				//self.sequence[self.arrayPos] 获取即将打印的字符串的序号
				//self.arrayPos为当前正在打印的字符串位于数组的位置一个标记
				//self.startPos为当前正在打印字符串的字符开始的位置
				self.typewrite(self.strings[self.sequence[self.arrayPos]], self.strPos);
			}, self.startDelay);
		},

		build: function() {
			var self = this;
			if (this.showCursor === true) {
				this.cursor = document.createElement('span');
				this.cursor.className = 'typed-cursor';
				this.cursor.innerHTML = this.cursorChar;
				/* this.el 指向当前的元素为#typed元素 */
				/* 元素添加到制定的位置 */
				this.el.parentNode && this.el.parentNode.insertBefore(this.cursor, this.el.nextSibling);
			}
			if (this.stringsElement) {
				/* 指定的元素存在的时候，将元素添加到字符串中 */
				this.strings = [];
				this.stringsElement.style.display = 'none';
				var strings = Array.prototype.slice.apply(this.stringsElement.children);
				strings.forEach(function(stringElement){
					self.strings.push(stringElement.innerHTML);
				});
			}
			this.init();
		},
		//不断的调用这个函数，用来不断的打印字符
		typewrite: function(curString, curStrPos) {
			//curString为当前正在打印的字符串
			//curStrPos为打印当前字符串中字符开始位置
			if (this.stop === true) {
				return;
			}
			/* 如果不删除相关的css 则字符串不会显示出来 */
			if (this.fadeOut && this.el.classList.contains(this.fadeOutClass)) {
				this.el.classList.remove(this.fadeOutClass);
				//this.Cursor为设置的光标 用来显示设置的光标
				this.cursor.classList.remove(this.fadeOutClass);
			}
			//生成一个随机的时间范围，显得更自然，只有当每次打印一个新字符串时才触发
			var humanize = Math.round(Math.random() * (100 - 30)) + this.typeSpeed;
			var self = this;
			self.timeout = setTimeout(function() {
				var charPause = 0;
				var substr = curString.substr(curStrPos);
				if (substr.charAt(0) === '^') {
					var skip = 1; // skip atleast 1
					if (/^\^\d+/.test(substr)) {
						substr = /\d+/.exec(substr)[0];
						skip += substr.length;
						charPause = parseInt(substr);
					}
					curString = curString.substring(0, curStrPos) + curString.substring(curStrPos + skip);
				}
				/* curString为转义之后的字符串，只包含字符*/
				/* curStrPos为当前的字符的位置索引 */
				if (self.contentType === 'html') {
					// skip over html tags while typing
					var curChar = curString.substr(curStrPos).charAt(0);
					if (curChar === '<' || curChar === '&') {
						var tag = '';
						var endTag = '';
						if (curChar === '<') {
							endTag = '>'
						}
						else {
							endTag = ';'
						}
						while (curString.substr(curStrPos + 1).charAt(0) !== endTag) {
							tag += curString.substr(curStrPos).charAt(0);
							curStrPos++;
							if (curStrPos + 1 > curString.length) { break; }
						}
						curStrPos++;
						tag += endTag;
					}
				}
				/* curString为当前完整的的字符串*/
				self.timeout = setTimeout(function() {
					//当前的字符串全部打印完成
					if (curStrPos === curString.length) {
						// 触发一个回调函数
						self.options.onStringTyped(self.arrayPos);
						// 当前打印的字符串是数组中的最后一个字符串
						if (self.arrayPos === self.strings.length - 1) {
							self.options.callback();
							//当前的循环次数增加，可以设置loopCount，如果相等表示达到上限
							self.curLoop++;
							/* 当所有的字符串打印完成之后，如果不循环打印，则退出函数，并且最后的字符串显示不删除 */
							if (self.loop === false || self.curLoop === self.loopCount)
								return;
						}
						/* 调用函数，实现字符串的退格效果，删除字符串 */
						self.timeout = setTimeout(function() {
							/*  typeWrite结束，backSpace中继续调用 */
							self.backspace(curString, curStrPos);
						}, self.backDelay);

					} else {
						/* 开始打印当前的字符串之前，调用函数 */
						if (curStrPos === 0) {
							self.options.preStringTyped(self.arrayPos);
						}
						/*  提取当前的字符串 */
						var nextString = curString.substring(0, curStrPos + 1);
						if (self.attr) {
							self.el.setAttribute(self.attr, nextString);
						} else {
							if (self.isInput) {
								self.el.value = nextString;
							} else if (self.contentType === 'html') {
								self.el.innerHTML = nextString;
							} else {
								self.el.textContent = nextString;
							}
						}
						/* 提取下一个位置组成的子字符串 */
						curStrPos++;
						/* 调用函数，继续提取子字符串并且显示 */
						self.typewrite(curString, curStrPos);
					}
				}, charPause);
			}, humanize);
		},

		/* backspace是typeWrite的逆向操作，用来提取string(0,curpos)的字符串 */
		/* curpos会不断的减小，直到0，表示该字符串的操作完成 */
		backspace: function(curString, curStrPos) {
			var self = this;
			if (this.stop === true) {
				return;
			}
			if (this.fadeOut){
				this.initFadeOut();
				return;
			}
			/* typeWrite中相同，生成随机的实践 */
			var humanize = Math.round(Math.random() * (100 - 30)) + this.backSpeed;
			self.timeout = setTimeout(function() {
				if (self.contentType === 'html') {
					if (curString.substr(curStrPos).charAt(0) === '>') {
						var tag = '';
						while (curString.substr(curStrPos - 1).charAt(0) !== '<') {
							tag -= curString.substr(curStrPos).charAt(0);
							curStrPos--;
							if (curStrPos < 0) { break; }
						}
						curStrPos--;
						tag += '<';
					}
				}
				/* 提取curString(0,curpos)的字符串 */
				var nextString = curString.substr(0, curStrPos);
				self.replaceText(nextString);
				if (curStrPos > self.stopNum) {
					curStrPos--;
					self.backspace(curString, curStrPos);
				}
				else if (curStrPos <= self.stopNum) {
					self.arrayPos++;
					if (self.arrayPos === self.strings.length) {
						self.arrayPos = 0;
						if(self.shuffle) self.sequence = self.shuffleArray(self.sequence);
						self.init();
					} else
						/* 打印数组中的下一个字符串，直到全部打印完成 */
						self.typewrite(self.strings[self.sequence[self.arrayPos]], curStrPos);
				}
			}, humanize);

		},

		initFadeOut: function(){
			self = this;
			this.el.className += ' ' + this.fadeOutClass;
			this.cursor.className += ' ' + this.fadeOutClass;
			return setTimeout(function() {
				self.arrayPos++;
				self.replaceText('');

				if(self.strings.length > self.arrayPos) {
					self.typewrite(self.strings[self.sequence[self.arrayPos]], 0);
				} else {
					self.typewrite(self.strings[0], 0);
					self.arrayPos = 0;
				}
			}, self.fadeOutDelay);
		},

		replaceText: function(str) {
			if (this.attr) {
				this.el.setAttribute(this.attr, str);
			} else {
				if (this.isInput) {
					this.el.value = str;
				} else if (this.contentType === 'html') {
					this.el.innerHTML = str;
				} else {
					this.el.textContent = str;
				}
			}
		},

		shuffleArray: function(array) {
			var tmp, current, top = array.length;
			if(top) while(--top) {
				current = Math.floor(Math.random() * (top + 1));
				tmp = array[current];
				array[current] = array[top];
				array[top] = tmp;
			}
			return array;
		},

		/* loop为true的时候，重新开始执行函数，不断的循环 */
		reset: function() {
			var self = this;
			clearInterval(self.timeout);
			var id = this.el.getAttribute('id');
			this.el.textContent = '';
			if (typeof this.cursor !== 'undefined' && typeof this.cursor.parentNode !== 'undefined') {
				this.cursor.parentNode.removeChild(this.cursor);
			}
			this.strPos = 0;
			this.arrayPos = 0;
			this.curLoop = 0;
			this.options.resetCallback();
		}
	};

	Typed.new = function(selector, option) {
		var elements = Array.prototype.slice.apply(document.querySelectorAll(selector));
		elements.forEach(function(element) {
			var instance = element._typed,
			    options = typeof option == 'object' && option;
			if (instance) { instance.reset(); }
			element._typed = instance = new Typed(element, options);
			if (typeof option == 'string') instance[option]();
		});
	};

	if ($) {
		$.fn.typed = function(option) {
			return this.each(function() {
				var $this = $(this),
				    data = $this.data('typed'),
				    options = typeof option == 'object' && option;
				if (data) { data.reset(); }
				$this.data('typed', (data = new Typed(this, options)));
				if (typeof option == 'string') data[option]();
			});
		};
	}

	window.Typed = Typed;

	var defaults = {
		//默认显示的字符串
		strings: ["Welcome you here!", "This is my personal blog!", "I am MisclKIM!"],
		//可以预先设置p元素来存放将要显示的字符串 p元素的clss属性必须是typed-strings
		stringsElement: null,
		//打字的速度
		typeSpeed: 0,
		//两个字符串打印之间的间隔
		startDelay: 0,
		//删除的速度
		backSpeed: 0,
		//随机打印字符串
		shuffle: false,
		//打印完成，准备删除之前的时间间隔
		backDelay: 500,
		//是否淡出
		fadeOut: false,
		//淡出效果的clss名称
		fadeOutClass: 'typed-fade-out',
		//淡出的时间
		fadeOutDelay: 500,
		//是否显示光标
		showCursor: true,
		//设置光标显示的字符串
		cursorChar: "|",
		//根据当前的字符索引设置一个属性
		attr: null,
		//输出内容的类型 html,content
		contentType: 'html',
		//所有的字符串全部打印完成的回调
		callback: function() {},
		//一个字符串打印之前的回调
		preStringTyped: function() {},
		//打印过程中的回调
		onStringTyped: function() {},
		//loop为true时，重新开始时候触发的回调
		resetCallback: function() {}
	};

}(window, document, window.jQuery);
